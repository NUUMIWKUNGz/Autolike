from Config import Config

dtlike = Config().Get()["configweb"]["dtlike"]

print(dtlike["1"]["name"])
    # print(f"{dtlike[i]['name']} price {dtlike[i]['price']}")
    
    